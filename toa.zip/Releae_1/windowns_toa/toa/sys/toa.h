#ifndef _TOA_H_
#define _TOA_H_

#include <ntddk.h>

struct hlist_head {
	struct hlist_node *first;
};

typedef struct hlist_head HLIST_HEAD;

struct hlist_node {
	struct hlist_node *next, **pprev;
};

typedef struct hlist_node HLIST_NODE;

#define INIT_HLIST_HEAD(ptr) ((ptr)->first = NULL)
static inline void INIT_HLIST_NODE(struct hlist_node *h)
{
	h->next = NULL;
	h->pprev = NULL;
}

static inline int hlist_unhashed(const struct hlist_node *h)
{
	return !h->pprev;
}

static inline int hlist_empty(const struct hlist_head *h)
{
	return !h->first;
}

static inline void __hlist_del(struct hlist_node *n)
{
	struct hlist_node *next = n->next;
	struct hlist_node **pprev = n->pprev;
	*pprev = next;
	if (next)
		next->pprev = pprev;
}

static inline void hlist_del(struct hlist_node *n)
{
	__hlist_del(n);
	n->next = NULL;
	n->pprev = NULL;
}

static inline void hlist_add_head(struct hlist_node *n, struct hlist_head *h)
{
	struct hlist_node *first = h->first;
	n->next = first;
	if (first)
		first->pprev = &n->next;
	h->first = n;
	n->pprev = &h->first;
}

#define TCP_URG_FLAG 0x20
#define TCP_ACK_FLAG 0x10
#define TCP_PSH_FLAG 0x08
#define TCP_RST_FLAG 0x04
#define TCP_SYN_FLAG 0x02
#define TCP_FIN_FLAG 0x01

#define TOA_FLOW_CONTEXT_POOL_TAG 'olfD'

#define DEVICE_NAME L"\\Device\\Toa_Device"
#define DEVICE_SYMBOLIC_NAME L"\\DosDevices\\Global\\Toa_Device"

#define  IOCTL_GET_REAL_REMOTE \
    CTL_CODE( FILE_DEVICE_NETWORK, 0x1, METHOD_BUFFERED, FILE_ANY_ACCESS )
#define  IOCTL_GET_STATS \
    CTL_CODE( FILE_DEVICE_NETWORK, 0x2, METHOD_BUFFERED, FILE_ANY_ACCESS )

#define TCPOPT_TOA 200
#define TCPOLEN_TOA 8
#define TCPOPT_NOP 1
#define TCPOPT_EOL 0

struct ToaRequest {
	UINT32 addr;
	UINT16 port;
};

struct ToaResponse {
	UINT32 addr;
	UINT16 port;
};

struct ToaStats {
	ULONG layerData;
	ULONG headerSize;
	ULONG header;
	ULONG toa;
	ULONG memory;
	ULONG associate;
	ULONG success;
};

/*
struct iphdr {
UINT8 ihl_version;
UINT8    tos;
UINT16  tot_len;
UINT16  id;
UINT16  frag_off;
UINT8   ttl;
UINT8   protocol;
UINT16  check;
UINT32  saddr;
UINT32  daddr;
};
*/

struct tcphdr {
	UINT16 source;
	UINT16 dest;
	UINT32 seq;
	UINT32 ack_seq;
	UINT8 doff;
	UINT8 tcp_flags;
	UINT16 window;
	UINT16 check;
	UINT16 urg_ptr;
};

struct toa_data
{
	UINT8 opcode;
	UINT8 opsize;
	UINT16 port;
	UINT32 addr;
};


typedef struct TOA_FLOW_CONTEXT_
{
	HLIST_NODE listEntry;

	BOOLEAN deleted;

	UINT64 flowId;
	UINT16 layerId;
	UINT32 calloutId;

	UINT32 Addr;
	UINT32 RemoteAddr;
	UINT16 Port;
	UINT16 RemotePort;

	LONG refCount;
}TOA_FLOW_CONTEXT;

enum
{
	TOA_COUNTER_NO_LAYERDATA,
	TOA_COUNTER_NO_HEADERSIZE,
	TOA_COUNTER_NO_HEADER,
	TOA_COUNTER_NO_TOA,
	TOA_COUNTER_NO_MEM,
	TOA_COUNTER_NO_ASSOCIATE,
	TOA_COUNTER_OK,
	TOA_COUNTER_LAST
};

#define TOA_COUNTER_MAX (TOA_COUNTER_LAST - 1)
#define TOA_HASH_SIZE 1024


__inline void
ToaReferenceFlowContext(
	_Inout_ TOA_FLOW_CONTEXT* flowContext
)
{
	NT_ASSERT(flowContext->refCount > 0);
	InterlockedIncrement(&flowContext->refCount);
}

_IRQL_requires_max_(DISPATCH_LEVEL)
__inline
void
ToaDereferenceFlowContext(
	_Inout_ TOA_FLOW_CONTEXT* flowContext
)
{
	NT_ASSERT(flowContext->refCount > 0);
	InterlockedDecrement(&flowContext->refCount);
	if (flowContext->refCount == 0)
	{
		ExFreePoolWithTag(flowContext, TOA_FLOW_CONTEXT_POOL_TAG);
	}
}



#endif
