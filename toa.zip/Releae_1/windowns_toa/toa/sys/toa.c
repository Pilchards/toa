﻿#include <ntddk.h>
#include <wdf.h>

#pragma warning(push)
#pragma warning(disable:4201)

#include <fwpsk.h>

#pragma waring(pop)

#include <fwpmk.h>

#include <ws2ipdef.h>
#include <in6addr.h>
#include <ip2string.h>

#define INITGUID
#include <guiddef.h>

#include "toa.h"

LONG toaStats[TOA_COUNTER_MAX];

DEVICE_OBJECT* gWdmDevice;
HANDLE gInjectionHandle;
HANDLE gEngineHandle;
UINT32 gToaRecvAcceptCalloutIdV4, gToaStreamPacketCalloutIdV4;
BOOLEAN gDriverUnloading = FALSE;

HLIST_HEAD gFlowList[TOA_HASH_SIZE];
KSPIN_LOCK gFlowListLock;

EVT_WDF_DRIVER_UNLOAD EvtDriverUnload;

UINT16   configInspectPort = 5001;
UINT32   configInspectAddr = 0;//0xa133da7;
UINT32 cnt = 0;

// ee93719d-ad5d-48c9-ae46-7270367d205d
DEFINE_GUID(
	TOA_RECV_ACCEPT_CALLOUT_V4,
	0xee93719d,
	0xad5d,
	0x48c9,
	0xae, 0x46, 0x72, 0x70, 0x36, 0x7d, 0x20, 0x5d
);

// b16b0a6e-2b2a-41a3-8b39-bd3ffc855ff8
DEFINE_GUID(
	TOA_STREAM_PACKET_CALLOUT_V4,
	0xb16b0a6e,
	0x2b2a,
	0x41a3,
	0x8b, 0x39, 0xbd, 0x3f, 0xfc, 0x85, 0x5f, 0xf8
);

// 0104fd7e-c825-414e-94c9-f0d525bbc169
DEFINE_GUID(
	TOA_SUBLAYER,
	0x0104fd7e,
	0xc825,
	0x414e,
	0x94, 0xc9, 0xf0, 0xd5, 0x25, 0xbb, 0xc1, 0x69
);


NTSTATUS
ToaAddFilter(
	_In_ const PWSTR filterName,
	_In_ const PWSTR filterDesc,
	_In_ const UINT32 Addr,
	_In_ USHORT Port,
	_In_ UINT8 protocol,
	_In_ const GUID* layerKey,
	_In_ const GUID* calloutKey
)
{
	NTSTATUS status = STATUS_SUCCESS;

	FWPM_FILTER filter = { 0 };
	FWPM_FILTER_CONDITION filterConditions[3] = { 0 };
	UINT conditionIndex;

	filter.layerKey = *layerKey;
	filter.displayData.name = (wchar_t*)filterName;
	filter.displayData.description = (wchar_t*)filterDesc;

	filter.action.type = FWP_ACTION_CALLOUT_TERMINATING;
	filter.action.calloutKey = *calloutKey;
	filter.filterCondition = filterConditions;
	filter.subLayerKey = TOA_SUBLAYER;
	filter.weight.type = FWP_EMPTY; // auto-weight.

	conditionIndex = 0;
	
	if (Addr)
	{
		//TODO: LOCAL
		KdPrint(("add file"));
		filterConditions[conditionIndex].fieldKey =
			FWPM_CONDITION_IP_LOCAL_ADDRESS;
		filterConditions[conditionIndex].matchType = FWP_MATCH_EQUAL;

		filterConditions[conditionIndex].conditionValue.type = FWP_UINT32;
		filterConditions[conditionIndex].conditionValue.uint32 = Addr;

		conditionIndex++;
	}
	
	if (protocol)
	{
		filterConditions[conditionIndex].fieldKey =
			FWPM_CONDITION_IP_PROTOCOL;
		filterConditions[conditionIndex].matchType = FWP_MATCH_EQUAL;
		filterConditions[conditionIndex].conditionValue.type = FWP_UINT8;
		filterConditions[conditionIndex].conditionValue.uint8 = IPPROTO_TCP;

		conditionIndex++;
	}
	
	if (Port)
	{
		filterConditions[conditionIndex].fieldKey = FWPM_CONDITION_IP_LOCAL_PORT;
		filterConditions[conditionIndex].matchType = FWP_MATCH_EQUAL;
		filterConditions[conditionIndex].conditionValue.type = FWP_UINT16;
		filterConditions[conditionIndex].conditionValue.uint16 = Port;

		conditionIndex++;
	}

	filter.numFilterConditions = conditionIndex;

	status = FwpmFilterAdd(
		gEngineHandle,
		&filter,
		NULL,
		NULL);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("filter ADD fail, status %x\n", status));
	}

	return status;
}

/*
* Funcs for toa hooks
*/

/* Parse TCP options in skb, try to get client ip, port
* @param skb [in] received skb, it should be a ack/get-ack packet.
* @return NULL if we don't get client ip/port;
*         value of toa_data in ret_ptr if we get client ip/port.
*/
static BOOL get_toa_data(struct tcphdr *th, UINT32 TcpHeaderSize, struct toa_data *toa)
{
	
	int length;
	unsigned char *ptr;
	struct toa_data tdata;

	
	if (NULL != th) {
		length = TcpHeaderSize - sizeof(struct tcphdr);
		ptr = (unsigned char *)(th + 1);
			while (length > 0) {
				int opcode = *ptr++;
				int opsize;
				switch (opcode) {
				case TCPOPT_EOL:
					return FALSE;
				case TCPOPT_NOP:	/* Ref: RFC 793 section 3.1 */
					length--;
					continue;
				default:
					opsize = *ptr++; 
					if (opsize < 2)	/* "silly options" */
						return FALSE;
					if (opsize > length)
						return FALSE;	/* don't parse partial options */
				
					if (TCPOPT_TOA == opcode && TCPOLEN_TOA == opsize) {
						memcpy(toa, ptr - 2, sizeof(tdata));
						//KdPrint(("find toa data: ip = %x, port = %d\n", toa->addr, toa->port));
						return TRUE;
					}
					ptr += opsize - 2;
					length -= opsize;
				}
			}
		}
	return FALSE;
}

#if(NTDDI_VERSION >= NTDDI_WIN7)
void
ToaRecvAcceptClassify(
	_In_ const FWPS_INCOMING_VALUES* inFixedValues,
	_In_ const FWPS_INCOMING_METADATA_VALUES* inMetaValues,
	_Inout_opt_ void* layerData,
	_In_opt_ const void* classifyContext,
	_In_ const FWPS_FILTER* filter,
	_In_ UINT64 flowContext,
	_Inout_ FWPS_CLASSIFY_OUT* classifyOut
)
	
#else
void
ToaRecvAcceptClassify(
	_In_ const FWPS_INCOMING_VALUES* inFixedValues,
	_In_ const FWPS_INCOMING_METADATA_VALUES* inMetaValues,
	_Inout_opt_ void* layerData,
	_In_ const FWPS_FILTER* filter,
	_In_ UINT64 flowContext,
	_Inout_ FWPS_CLASSIFY_OUT* classifyOut
)
#endif /// (NTDDI_VERSION >= NTDDI_WIN7)
{
	UNREFERENCED_PARAMETER(inFixedValues);
	UNREFERENCED_PARAMETER(inMetaValues);
	UNREFERENCED_PARAMETER(filter);
	UNREFERENCED_PARAMETER(flowContext);
	UNREFERENCED_PARAMETER(classifyOut);
	UNREFERENCED_PARAMETER(classifyContext);

	NET_BUFFER_LIST *list = layerData;
	NET_BUFFER* netBuffer;
	NDIS_STATUS ndisStatus;
	//struct iphdr *ipHeader;
	struct tcphdr *tcpHeader;
	NTSTATUS status = STATUS_SUCCESS;
	BOOLEAN locked = FALSE;
	struct toa_data toa;
	KLOCK_QUEUE_HANDLE flowListLockHandle;
	TOA_FLOW_CONTEXT *flowContextLocal = NULL;
	UINT32 hash;
	BOOL ret;
	

	UINT32 transportHeaderSize = inMetaValues->transportHeaderSize;
	UINT32 ipHeaderSize = inMetaValues->ipHeaderSize;
	if (layerData == NULL) {
		InterlockedIncrement(&toaStats[TOA_COUNTER_NO_LAYERDATA]);
		goto Exit;
	}
	else if (!transportHeaderSize || !ipHeaderSize)
	{
		InterlockedIncrement(&toaStats[TOA_COUNTER_NO_HEADERSIZE]);
		goto Exit;
	}
	else
	{
		netBuffer = NET_BUFFER_LIST_FIRST_NB(list);

		ndisStatus = NdisRetreatNetBufferDataStart(
			netBuffer,
			transportHeaderSize,
			0,
			NULL);

		tcpHeader = NdisGetDataBuffer(
			netBuffer,
			transportHeaderSize,
			NULL,
			sizeof(UINT16),
			0
		);

		if (!tcpHeader)
		{
			InterlockedIncrement(&toaStats[TOA_COUNTER_NO_HEADER]);
			goto Exit;
		}

		ret = get_toa_data(tcpHeader, transportHeaderSize, &toa);

		NdisAdvanceNetBufferDataStart(
			netBuffer,
			transportHeaderSize,
			FALSE,
			NULL
		);

		if (!ret)
		{
			InterlockedIncrement(&toaStats[TOA_COUNTER_NO_TOA]);
			goto Exit;
		}
	}

	flowContextLocal = ExAllocatePoolWithTag(
		NonPagedPool,
		sizeof(TOA_FLOW_CONTEXT),
		TOA_FLOW_CONTEXT_POOL_TAG
	);
	if (flowContextLocal == NULL)
	{
		InterlockedIncrement(&toaStats[TOA_COUNTER_NO_MEM]);
		goto Exit;
	}

	RtlZeroMemory(flowContextLocal, sizeof(TOA_FLOW_CONTEXT));

	flowContextLocal->refCount = 1;
	flowContextLocal->layerId = FWPS_LAYER_STREAM_PACKET_V4;
	flowContextLocal->calloutId = gToaStreamPacketCalloutIdV4;
	flowContextLocal->flowId = inMetaValues->flowHandle;
	flowContextLocal->RemoteAddr = RtlUlongByteSwap(toa.addr);;
	flowContextLocal->RemotePort = RtlUshortByteSwap(toa.port);
	flowContextLocal->Addr = inFixedValues->incomingValue\
		[FWPS_FIELD_ALE_AUTH_RECV_ACCEPT_V4_IP_REMOTE_ADDRESS].value.uint32;
	flowContextLocal->Port = inFixedValues->incomingValue\
		[FWPS_FIELD_ALE_AUTH_RECV_ACCEPT_V4_IP_REMOTE_PORT].value.uint16;
	INIT_HLIST_NODE(&flowContextLocal->listEntry);

	hash = (flowContextLocal->Addr + flowContextLocal->Port) & 0x3ff;

	KeAcquireInStackQueuedSpinLock(
		&gFlowListLock,
		&flowListLockHandle
	);

	locked = TRUE;

	if (!gDriverUnloading)
	{
		status = FwpsFlowAssociateContext(
			inMetaValues->flowHandle,
			FWPS_LAYER_STREAM_PACKET_V4,
			gToaStreamPacketCalloutIdV4,
			(UINT64)flowContextLocal
		);
		if (!NT_SUCCESS(status))
		{
			InterlockedIncrement(&toaStats[TOA_COUNTER_NO_ASSOCIATE]);
			goto Exit;
		}
		hlist_add_head(&flowContextLocal->listEntry, &gFlowList[hash]);
		//KdPrint(("flow hash %d add %x:%d ---> %x:%d\n", hash, flowContextLocal->Addr, flowContextLocal->Port, flowContextLocal->RemoteAddr, flowContextLocal->RemotePort));
		flowContextLocal = NULL;
		InterlockedIncrement(&toaStats[TOA_COUNTER_OK]);
	}	

Exit:
	if (locked)
	{
		KeReleaseInStackQueuedSpinLock(&flowListLockHandle);
	}

	if (flowContextLocal != NULL)
	{
		ExFreePoolWithTag(flowContextLocal, TOA_FLOW_CONTEXT_POOL_TAG);
	}

	classifyOut->actionType = FWP_ACTION_PERMIT;

	if (filter->flags & FWPS_FILTER_FLAG_CLEAR_ACTION_RIGHT)
	{
		classifyOut->rights &= ~FWPS_RIGHT_ACTION_WRITE;
	}
}

NTSTATUS
ToaRecvAcceptNotify(
	_In_ FWPS_CALLOUT_NOTIFY_TYPE notifyType,
	_In_ const GUID* filterKey,
	_Inout_ const FWPS_FILTER* filter
)
{
	UNREFERENCED_PARAMETER(notifyType);
	UNREFERENCED_PARAMETER(filterKey);
	UNREFERENCED_PARAMETER(filter);

	return STATUS_SUCCESS;
}

NTSTATUS
ToaRegisterRecvAcceptCallouts(
	_In_ const GUID* layerKey,
	_In_ const GUID* calloutKey,
	_Inout_ void* deviceObject,
	_Out_ UINT32* calloutId
)
{
	NTSTATUS status = STATUS_SUCCESS;

	FWPS_CALLOUT sCallout = { 0 };
	FWPM_CALLOUT mCallout = { 0 };

	FWPM_DISPLAY_DATA displayData = { 0 };

	BOOLEAN calloutRegistered = FALSE;

	sCallout.calloutKey = *calloutKey;
	sCallout.classifyFn = ToaRecvAcceptClassify;
	sCallout.notifyFn = ToaRecvAcceptNotify;

	status = FwpsCalloutRegister(
		deviceObject,
		&sCallout,
		calloutId
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}
	calloutRegistered = TRUE;

	displayData.name = L"Toa RecvAcceptCallout";
	displayData.description =
		L"Intercepts RecvAccept for the Toa";

	mCallout.calloutKey = *calloutKey;
	mCallout.displayData = displayData;
	mCallout.applicableLayer = *layerKey;

	status = FwpmCalloutAdd(
		gEngineHandle,
		&mCallout,
		NULL,
		NULL
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}

	status = ToaAddFilter(
		L"Toa RecvAccept",
		L"Intercepts RecvAccept for Toa",
		configInspectAddr,
		configInspectPort,
		1,
		layerKey,
		calloutKey
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("recvaccept add filter fail\n"));
		goto Exit;
	}

Exit:
	if (!NT_SUCCESS(status))
	{
		if (calloutRegistered)
		{
			FwpsCalloutUnregisterById(*calloutId);
			*calloutId = 0;
		}
	}

	return status;
}


#if(NTDDI_VERSION >= NTDDI_WIN7)
void
ToaStreamPacketClassify(
	_In_ const FWPS_INCOMING_VALUES* inFixedValues,
	_In_ const FWPS_INCOMING_METADATA_VALUES* inMetaValues,
	_Inout_opt_ void* layerData,
	_In_opt_ const void* classifyContext,
	_In_ const FWPS_FILTER* filter,
	_In_ UINT64 flowContext,
	_Inout_ FWPS_CLASSIFY_OUT* classifyOut
)

#else
void
ToaStreamPacketClassify(
	_In_ const FWPS_INCOMING_VALUES* inFixedValues,
	_In_ const FWPS_INCOMING_METADATA_VALUES* inMetaValues,
	_Inout_opt_ void* layerData,
	_In_ const FWPS_FILTER* filter,
	_In_ UINT64 flowContext,
	_Inout_ FWPS_CLASSIFY_OUT* classifyOut
)
#endif /// (NTDDI_VERSION >= NTDDI_WIN7)
{
	UNREFERENCED_PARAMETER(inFixedValues);
	UNREFERENCED_PARAMETER(inMetaValues);
	UNREFERENCED_PARAMETER(layerData);
	UNREFERENCED_PARAMETER(filter);
	UNREFERENCED_PARAMETER(flowContext);
	UNREFERENCED_PARAMETER(classifyOut);
	UNREFERENCED_PARAMETER(classifyContext);

	classifyOut->actionType = FWP_ACTION_PERMIT;

	if (filter->flags & FWPS_FILTER_FLAG_CLEAR_ACTION_RIGHT)
	{
		classifyOut->rights &= ~FWPS_RIGHT_ACTION_WRITE;
	}
}

NTSTATUS
ToaStreamPacketNotify(
	_In_ FWPS_CALLOUT_NOTIFY_TYPE notifyType,
	_In_ const GUID* filterKey,
	_Inout_ const FWPS_FILTER* filter
)
{
	UNREFERENCED_PARAMETER(notifyType);
	UNREFERENCED_PARAMETER(filterKey);
	UNREFERENCED_PARAMETER(filter);

	return STATUS_SUCCESS;
}

void
ToaStreamPacketFlowDelete(
	_In_ UINT16 layerId,
	_In_ UINT32 calloutId,
	_In_ UINT64 flowContext
)
/* ++

This is the flowDeleteFn function of the datagram-data callout. It
removes the flow context from the global flow list and dereference the
context.

-- */
{
	UNREFERENCED_PARAMETER(layerId);
	UNREFERENCED_PARAMETER(calloutId);
	UNREFERENCED_PARAMETER(flowContext);

	TOA_FLOW_CONTEXT* flowContextLocal = (TOA_FLOW_CONTEXT*)(DWORD_PTR)flowContext;
	
	KLOCK_QUEUE_HANDLE flowListLockHandle;

	KeAcquireInStackQueuedSpinLock(
		&gFlowListLock,
		&flowListLockHandle
	);

	if (!flowContextLocal->deleted)
	{
		hlist_del(&flowContextLocal->listEntry);
	}

	KeReleaseInStackQueuedSpinLock(&flowListLockHandle);
	ToaDereferenceFlowContext(flowContextLocal);
}


NTSTATUS
ToaRegisterStreamPacketCallouts(
	_In_ const GUID* layerKey,
	_In_ const GUID* calloutKey,
	_Inout_ void* deviceObject,
	_Out_ UINT32* calloutId
)
{
	NTSTATUS status = STATUS_SUCCESS;

	FWPS_CALLOUT sCallout = { 0 };
	FWPM_CALLOUT mCallout = { 0 };

	FWPM_DISPLAY_DATA displayData = { 0 };

	BOOLEAN calloutRegistered = FALSE;

	sCallout.calloutKey = *calloutKey;
	sCallout.classifyFn = ToaStreamPacketClassify;
	sCallout.notifyFn = ToaStreamPacketNotify;
	sCallout.flowDeleteFn = ToaStreamPacketFlowDelete;
	sCallout.flags = FWP_CALLOUT_FLAG_CONDITIONAL_ON_FLOW;

	status = FwpsCalloutRegister(
		deviceObject,
		&sCallout,
		calloutId
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}
	calloutRegistered = TRUE;

	displayData.name = L"Toa StreamPacket Callout";
	displayData.description =
		L"Intercepts StreamPacket for the Toa";

	mCallout.calloutKey = *calloutKey;
	mCallout.displayData = displayData;
	mCallout.applicableLayer = *layerKey;

	status = FwpmCalloutAdd(
		gEngineHandle,
		&mCallout,
		NULL,
		NULL
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}

	status = ToaAddFilter(
		L"Toa StreamPacket",
		L"Intercepts treamPacket for Toa",
		configInspectAddr,
		configInspectPort,
		0,
		layerKey,
		calloutKey
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("streampacket add filter fail\n"));
	}

Exit:
	if (!NT_SUCCESS(status))
	{
		if (calloutRegistered)
		{
			FwpsCalloutUnregisterById(*calloutId);
			*calloutId = 0;
		}
	}

	return status;
}


NTSTATUS
ToaRegisterCallouts(
	_Inout_ void* deviceObject
)
/* ++

This function registers dynamic callouts and filters that intercept UDP or
non-error ICMP traffic at WFP FWPM_LAYER_DATAGRAM_DATA_V{4|6} and
FWPM_LAYER_ALE_FLOW_ESTABLISHED_V{4|6} layers.

Callouts and filters will be removed during DriverUnload.

-- */
{
	NTSTATUS status = STATUS_SUCCESS;
	FWPM_SUBLAYER ToaSubLayer;

	BOOLEAN engineOpened = FALSE;
	BOOLEAN inTransaction = FALSE;

	FWPM_SESSION session = { 0 };

	session.flags = FWPM_SESSION_FLAG_DYNAMIC;

	status = FwpmEngineOpen(
		NULL,
		RPC_C_AUTHN_WINNT,
		NULL,
		&session,
		&gEngineHandle
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}
	engineOpened = TRUE;

	status = FwpmTransactionBegin(gEngineHandle, 0);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}
	inTransaction = TRUE;

	RtlZeroMemory(&ToaSubLayer, sizeof(FWPM_SUBLAYER));

	ToaSubLayer.subLayerKey = TOA_SUBLAYER;
	ToaSubLayer.displayData.name = L"Toa Sub-Layer";
	ToaSubLayer.displayData.description =
		L"Sub-Layer for use by Toa callouts";
	ToaSubLayer.flags = 0;
	ToaSubLayer.weight = FWP_EMPTY; // auto-weight.;

	status = FwpmSubLayerAdd(gEngineHandle, &ToaSubLayer, NULL);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}

	status = ToaRegisterRecvAcceptCallouts(
		&FWPM_LAYER_ALE_AUTH_RECV_ACCEPT_V4,
		&TOA_RECV_ACCEPT_CALLOUT_V4,
		deviceObject,
		&gToaRecvAcceptCalloutIdV4
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("register recvaccept callouts fail\n"));
		goto Exit;
	}

	status = ToaRegisterStreamPacketCallouts(
		&FWPM_LAYER_STREAM_PACKET_V4,
		&TOA_STREAM_PACKET_CALLOUT_V4,
		deviceObject,
		&gToaStreamPacketCalloutIdV4
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("register stream packet callouts fail\n"));
		goto Exit;
	}

	status = FwpmTransactionCommit(gEngineHandle);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}
	inTransaction = FALSE;

Exit:
	if (!NT_SUCCESS(status))
	{
		if (inTransaction)
		{
			FwpmTransactionAbort(gEngineHandle);
			_Analysis_assume_lock_not_held_(gEngineHandle); // Potential leak if "FwpmTransactionAbort" fails
		}
		if (engineOpened)
		{
			FwpmEngineClose(gEngineHandle);
			gEngineHandle = NULL;
		}
	}

	return status;
}

void
ToaUnregisterCallouts(void)
{
	if (gEngineHandle != NULL)
	{
		FwpmEngineClose(gEngineHandle);
		gEngineHandle = NULL;
	}

	if (gToaRecvAcceptCalloutIdV4 != 0)
		FwpsCalloutUnregisterById(gToaRecvAcceptCalloutIdV4);

	if (gToaStreamPacketCalloutIdV4 != 0)
		FwpsCalloutUnregisterById(gToaStreamPacketCalloutIdV4);
}

void
ToaRemoveFlows(void)
{
	UINT16 i;
	for (i = 0; i < TOA_HASH_SIZE; i++)
	{
		while (!hlist_empty(&gFlowList[i]))
		{
			KLOCK_QUEUE_HANDLE flowListLockHandle;
			HLIST_NODE* listEntry = NULL;
			TOA_FLOW_CONTEXT* flowContext;

			KeAcquireInStackQueuedSpinLock(
				&gFlowListLock,
				&flowListLockHandle
			);

			if (!hlist_empty(&gFlowList[i]))
			{
				listEntry = gFlowList[i].first;
				hlist_del(gFlowList[i].first);
			}

			//
			// Releasing the lock here since removing the flow context 
			// will invoke the callout's flowDeleteFn synchronously 
			// if there are no active classifications in progress.
			//
			KeReleaseInStackQueuedSpinLock(&flowListLockHandle);

			if (listEntry != NULL)
			{
				flowContext = CONTAINING_RECORD(
					listEntry,
					TOA_FLOW_CONTEXT,
					listEntry
				);

				flowContext->deleted = TRUE;

				FwpsFlowRemoveContext(
					flowContext->flowId,
					flowContext->layerId,
					flowContext->calloutId
				);

					}
		}
	}
}

void
EvtDriverUnload(
	_In_ WDFDRIVER driverObject
)
{
	KLOCK_QUEUE_HANDLE flowListLockHandle;

	UNREFERENCED_PARAMETER(driverObject);
	KdPrint(("in the unload\n"));

	KeAcquireInStackQueuedSpinLock(
		&gFlowListLock,
		&flowListLockHandle
	);

	gDriverUnloading = TRUE;

	KeReleaseInStackQueuedSpinLock(&flowListLockHandle);

	ToaRemoveFlows();

	ToaUnregisterCallouts();

	FwpsInjectionHandleDestroy(gInjectionHandle);
}

NTSTATUS findRealRemote(struct ToaResponse *resp, struct ToaRequest *req)
{
	NTSTATUS status = STATUS_NOT_FOUND;
	KLOCK_QUEUE_HANDLE flowListLockHandle;
	HLIST_NODE* listEntry = NULL;
	TOA_FLOW_CONTEXT* flowContext;
	UINT32 hash;

	KeAcquireInStackQueuedSpinLock(
		&gFlowListLock,
		&flowListLockHandle
	);

	hash = (req->addr + req->port) & 0x3ff;

	if (!hlist_empty(&gFlowList[hash])) {

		listEntry = gFlowList[hash].first;

		while (listEntry != NULL)
		{
			flowContext = CONTAINING_RECORD(
				listEntry,
				TOA_FLOW_CONTEXT,
				listEntry
			);

			if (flowContext->Addr == req->addr && flowContext->Port == req->port)
			{
				resp->addr = flowContext->RemoteAddr;
				resp->port = flowContext->RemotePort;
				status = STATUS_SUCCESS;
				break;
			}

			listEntry = listEntry->next;
		}
	}

	KeReleaseInStackQueuedSpinLock(&flowListLockHandle);

	return status;
}

void getStats(struct ToaStats *resp)
{
	resp->layerData = toaStats[TOA_COUNTER_NO_LAYERDATA];
	resp->headerSize = toaStats[TOA_COUNTER_NO_HEADERSIZE];
	resp->header = toaStats[TOA_COUNTER_NO_HEADER];
	resp->toa = toaStats[TOA_COUNTER_NO_TOA];
	resp->memory = toaStats[TOA_COUNTER_NO_MEM];
	resp->associate = toaStats[TOA_COUNTER_NO_ASSOCIATE];
	resp->success = toaStats[TOA_COUNTER_OK];
}

VOID
ToaDeviceControl(
	_In_ WDFQUEUE Queue,
	_In_ WDFREQUEST Request,
	_In_ size_t OutputBufferLength,
	_In_ size_t InputBufferLength,
	_In_ ULONG IoControlCode
)
/*++

Handles device IO control requests. This callback drives all communication
between the usermode exe and this driver.

--*/
{
	NTSTATUS status = STATUS_SUCCESS;

	UNREFERENCED_PARAMETER(Queue);
	UNREFERENCED_PARAMETER(OutputBufferLength);
	UNREFERENCED_PARAMETER(InputBufferLength);
	

	switch (IoControlCode)
	{
	case IOCTL_GET_REAL_REMOTE:
	{
		void* pBufferIn;
		void* pBufferOut;
		struct ToaRequest *req;
		struct ToaResponse *resp;

		if (InputBufferLength < sizeof(struct ToaRequest) || OutputBufferLength < sizeof(struct ToaResponse))
		{
			status = STATUS_INVALID_PARAMETER;
		}
		else
		{
			status = WdfRequestRetrieveInputBuffer(Request, sizeof(struct ToaRequest), &pBufferIn, NULL);
			if (NT_SUCCESS(status))
			{
				req = (struct ToaRequest *)pBufferIn;
				status = WdfRequestRetrieveOutputBuffer(Request, sizeof(struct ToaResponse), &pBufferOut, NULL);
				if (NT_SUCCESS(status))
				{
						resp = (struct ToaResponse *)pBufferOut;
					status = findRealRemote(resp, req);
					if (NT_SUCCESS(status))
						WdfRequestSetInformation(Request, sizeof(*resp));
				}
			}
		}
		break;
	}
	case IOCTL_GET_STATS:
	{
		void* pBufferOut;
		struct ToaStats *resp;

		if (OutputBufferLength < sizeof(struct ToaStats))
		{
			status = STATUS_INVALID_PARAMETER;
		}
		else
		{
			status = WdfRequestRetrieveOutputBuffer(Request, sizeof(struct ToaStats), &pBufferOut, NULL);
			if (NT_SUCCESS(status))
			{
				KdPrint(("in the stats output\n"));
				resp = (struct ToaStats *)pBufferOut;
				getStats(resp);
				WdfRequestSetInformation(Request, sizeof(*resp));
			}
		}
		break;
	}
	default:
	{
		status = STATUS_INVALID_PARAMETER;
	}
	}

	WdfRequestComplete(Request, status);
}

NTSTATUS
ToaCtlDriverInit(
	_In_ WDFDEVICE* pDevice
)
/*++

Routine Description:

Initializes the request queue for our driver.  This is how
DeviceIoControl requests are sent to KMDF drivers.

Arguments:

[in]  WDFDEVICE* pDevice - Our device.

--*/
{
	NTSTATUS status;
	WDF_IO_QUEUE_CONFIG queueConfig;

	WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(
		&queueConfig,
		WdfIoQueueDispatchSequential
	);

	queueConfig.EvtIoDeviceControl = ToaDeviceControl;

	status = WdfIoQueueCreate(
		*pDevice,
		&queueConfig,
		WDF_NO_OBJECT_ATTRIBUTES,
		NULL
	);

	return status;
}

NTSTATUS
ToaInitDriverObjects(
	_Inout_ DRIVER_OBJECT* driverObject,
	_In_ const UNICODE_STRING* registryPath,
	_Out_ WDFDRIVER* pDriver,
	_Out_ WDFDEVICE* pDevice
)
{
	NTSTATUS status;
	WDF_DRIVER_CONFIG config;
	PWDFDEVICE_INIT pInit = NULL;
	DECLARE_CONST_UNICODE_STRING(DeviceName, DEVICE_NAME);
	DECLARE_CONST_UNICODE_STRING(symbolicName, DEVICE_SYMBOLIC_NAME);

	WDF_DRIVER_CONFIG_INIT(
		&config,
		WDF_NO_EVENT_CALLBACK
	);

	config.DriverInitFlags |= WdfDriverInitNonPnpDriver;
	config.EvtDriverUnload = EvtDriverUnload;

	status = WdfDriverCreate(
		driverObject,
		registryPath,
		WDF_NO_OBJECT_ATTRIBUTES,
		&config,
		pDriver
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}

	pInit = WdfControlDeviceInitAllocate(
		*pDriver,
		&SDDL_DEVOBJ_SYS_ALL_ADM_ALL
	);
	if (!pInit)
	{
		status = STATUS_INSUFFICIENT_RESOURCES;
		KdPrint(("allocate pinit fail\n"));
		goto Exit;
	}

	WdfDeviceInitSetDeviceType(
		pInit,
		FILE_DEVICE_NETWORK
	);

	WdfDeviceInitSetCharacteristics(
		pInit,
		FILE_DEVICE_SECURE_OPEN,
		FALSE
	);

	status = WdfDeviceInitAssignName(
		pInit,
		&DeviceName
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("add name fail\n"));
		goto Exit;
	}

	status = WdfDeviceCreate(
		&pInit,
		WDF_NO_OBJECT_ATTRIBUTES,
		pDevice
	);
	if (!NT_SUCCESS(status))
	{
		goto Exit;
	}

	status = WdfDeviceCreateSymbolicLink(*pDevice, &symbolicName);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("add symbol name fail\n"));
		goto Exit;
	}

	status = ToaCtlDriverInit(pDevice);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("ioctl init fail\n"));
		goto Exit;
	}

	WdfControlFinishInitializing(*pDevice);

Exit:
	if (pInit)
	{
		WdfDeviceInitFree(pInit);
	}
	return status;
}

NTSTATUS
ToaLoadIPAddress(
	_In_ const WDFKEY key,
	_In_ const UNICODE_STRING* valueName,
	_Out_ UINT32* addr
)
{
	NTSTATUS status;
	PWSTR terminator;
	DECLARE_UNICODE_STRING_SIZE(value, INET_ADDRSTRLEN);
	IN_ADDR resultV4;

	status = WdfRegistryQueryUnicodeString(key, valueName, NULL, &value);

	if (NT_SUCCESS(status))
	{
		// The Registry API does not guarantee that the string will be
		// null-terminated.
		// Defensively null-terminate the string.
		value.Length = min(value.Length, value.MaximumLength - sizeof(WCHAR));
		value.Buffer[value.Length / sizeof(WCHAR)] = UNICODE_NULL;

		status = RtlIpv4StringToAddressW(
			value.Buffer,
			TRUE,
			&terminator,
			&resultV4
		);

		if (NT_SUCCESS(status))
		{
			*addr = RtlUlongByteSwap(resultV4.S_un.S_addr);
		}
	}

	return status;
}


void
ToaLoadConfig(
	_In_ const WDFKEY key
)
{
	DECLARE_CONST_UNICODE_STRING(AddrValueName, L"AddressToIntercept");
	DECLARE_CONST_UNICODE_STRING(PortValueName, L"PortToIntercept");

	ULONG ulongValue;
	UINT32 Addr;

	if (NT_SUCCESS(ToaLoadIPAddress(
		key,
		&AddrValueName,
		&Addr
	)))
	{
		configInspectAddr = Addr;
	}

	if (NT_SUCCESS(WdfRegistryQueryULong(
		key,
		&PortValueName,
		&ulongValue
	)))
	{
		configInspectPort = (USHORT)ulongValue;
	}

}


NTSTATUS DriverEntry(DRIVER_OBJECT* driverObject, UNICODE_STRING* registryPath)
{

    NTSTATUS NtStatus = STATUS_SUCCESS; 
	NTSTATUS status;
	WDFDRIVER driver;
	WDFDEVICE device;
	WDFKEY configKey;
	UINT16 i;

	// Request NX Non-Paged Pool when available
	ExInitializeDriverRuntime(DrvRtPoolNxOptIn);
    
	status = ToaInitDriverObjects(
		driverObject,
		registryPath,
		&driver,
		&device
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("init driver obj fail\n"));
		goto Exit;
	}

	status = WdfDriverOpenParametersRegistryKey(
		driver,
		KEY_READ,
		WDF_NO_OBJECT_ATTRIBUTES,
		&configKey
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("open parameters key fail\n"));
		goto Exit;
	}

	ToaLoadConfig(configKey);

	status = FwpsInjectionHandleCreate(
		AF_UNSPEC,
		FWPS_INJECTION_TYPE_TRANSPORT,
		&gInjectionHandle
	);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("inject handle create fail\n"));
		goto Exit;
	}

	for (i=0; i<TOA_HASH_SIZE; i++)
		INIT_HLIST_HEAD(&gFlowList[i]);
	KeInitializeSpinLock(&gFlowListLock);

	gWdmDevice = WdfDeviceWdmGetDeviceObject(device);

	status =ToaRegisterCallouts(gWdmDevice);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("register callout fail\n"));
		goto Exit;
	}
	KdPrint(("everthing go well"));

Exit:
	if (!NT_SUCCESS(status))
	{
		if (gInjectionHandle != NULL)
		{
			FwpsInjectionHandleDestroy(gInjectionHandle);
			gInjectionHandle = NULL;
		}
	}

    return NtStatus;
}
