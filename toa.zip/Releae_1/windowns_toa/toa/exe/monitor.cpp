/*
#include "windows.h"
#include "winioctl.h"
#include "strsafe.h"

#ifndef _CTYPE_DISABLE_MACROS
#define _CTYPE_DISABLE_MACROS
#endif

#include "fwpmu.h"

#include "winsock2.h"
#include "ws2def.h"

#include <conio.h>
#include <stdio.h>


#define INITGUID
#include <guiddef.h>
*/

#define UNICODE 1
#define _UNICODE 1
#define _WINSOCK_DEPRECATED_NO_WARNINGS

/* The code of interest is in the subroutine GetDriveGeometry. The
code in main shows how to interpret the results of the call. */

#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <winsock2.h>

#pragma comment(lib, "Ws2_32.lib")

#define wszDrive L"\\\\.\\Toa_Device"
#define  IOCTL_GET_REAL_REMOTE \
    CTL_CODE( FILE_DEVICE_NETWORK, 0x1, METHOD_BUFFERED, FILE_ANY_ACCESS )
#define  IOCTL_GET_STATS \
    CTL_CODE( FILE_DEVICE_NETWORK, 0x2, METHOD_BUFFERED, FILE_ANY_ACCESS )

struct ToaRequest {
	UINT32 addr;
	UINT16 port;
};

struct ToaResponse {
	UINT32 addr;
	UINT16 port;
};

struct ToaStats {
	ULONG layerData;
	ULONG headerSize;
	ULONG header;
	ULONG toa;
	ULONG memory;
	ULONG associate;
	ULONG success;
};

HANDLE hDevice = INVALID_HANDLE_VALUE;  // handle to the drive to be examined 

BOOL GetRealRemote(struct ToaRequest *req, struct ToaResponse *resp)
{
	BOOL bResult = FALSE;                 // results flag
	DWORD junk = 0;     // discard results

	bResult = DeviceIoControl(hDevice,                       // device to be queried
		IOCTL_GET_REAL_REMOTE, // operation to perform
		req, sizeof(*req),                       // no input buffer
		resp, sizeof(*resp),            // output buffer
		&junk,                         // # bytes returned
		(LPOVERLAPPED)NULL);          // synchronous I/O

	return (bResult);
}
BOOL GetToaStats(struct ToaStats *resp)
{
	BOOL bResult = FALSE;                 // results flag
	DWORD junk = 0;     // discard results

	bResult = DeviceIoControl(hDevice,                       // device to be queried
		IOCTL_GET_STATS, // operation to perform
		NULL, 0,                       // no input buffer
		resp, sizeof(*resp),            // output buffer
		&junk,                         // # bytes returned
		(LPOVERLAPPED)NULL);          // synchronous I/O

	return (bResult);
}


//int __cdecl wmain(_In_ int argc, _In_reads_(argc) PCWSTR argv[])
int main(int argc, char *argv[])
{
	UNREFERENCED_PARAMETER(argc);
	UNREFERENCED_PARAMETER(argv);
	printf("hello world \n");

	if (argc < 3)
	{
		printf("monitor.exe addr port\n");
		return 0;
	}

	printf("%s %s\n", argv[1], argv[2]);
	UINT16 port = (UINT16)atoi(argv[2]);
	UINT32 addr = ntohl(inet_addr(argv[1]));

	BOOL bResult = FALSE;      // generic results flag
	struct ToaResponse resp;
	memset(&resp, 0, sizeof(resp));

	struct ToaRequest req;
	req.addr = addr;
	req.port = port;

	printf("req %x:%d\n", req.addr, req.port);

	hDevice = CreateFileW(wszDrive,          // drive to open
		GENERIC_READ | GENERIC_WRITE,                // no access to the drive
		FILE_SHARE_READ | // share mode
		FILE_SHARE_WRITE,
		NULL,             // default security attributes
		OPEN_EXISTING,    // disposition
		0,                // file attributes
		NULL);            // do not copy file attributes
	if (hDevice == INVALID_HANDLE_VALUE)    // cannot open the drive
	{
		printf("no device %d\n", GetLastError());
		return 0;
	}

	bResult = GetRealRemote(&req, &resp);
	if (bResult)
	{
		printf("hahah return ok addr %x, port %x\n", resp.addr, resp.port);
	}
	else
	{
		printf("GetRealRemote failed. Error %ld.\n", GetLastError());
	}

	struct ToaStats statsResp;
	memset(&statsResp, 0, sizeof(statsResp));
	bResult = GetToaStats(&statsResp);
	if (bResult)
	{
		printf("getstats: %ld, %ld, %ld, %ld, %ld, %ld, %ld\n", statsResp.layerData, statsResp.headerSize, statsResp.header, statsResp.toa, statsResp.memory, statsResp.associate, statsResp.success);
	}
	else
	{
		printf("GetToaStats failed. Error %ld.\n", GetLastError());
	}

	CloseHandle(hDevice);

	return ((int)bResult);
}


